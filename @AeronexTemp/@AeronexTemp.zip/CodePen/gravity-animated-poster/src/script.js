/*
The pure CSS parallax star background has been forked from my other pen :

Parallax Star background in CSS
https://codepen.io/saransh/details/BKJun

Made by @saran5h
linkedin.com/in/saranshsinha
*/